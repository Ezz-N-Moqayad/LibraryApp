package com.example.libraryapp

class Book(
    var id: String = "",
    var Name_Book: String = "",
    var Name_Author: String = "",
    var Launch_Year: String = "",
    var Price_Book: String = "",
    var Image_Book: String = "",
    var Uri_Video: String = "",
    var Book_Review: String = ""
)